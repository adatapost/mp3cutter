<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> Partial Class frmMain
#Region "Windows Form Designer generated code "
	<System.Diagnostics.DebuggerNonUserCode()> Public Sub New()
		MyBase.New()
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents Command1 As System.Windows.Forms.Button
	Public WithEvents Command2 As System.Windows.Forms.Button
	Public WithEvents lstPlayList As System.Windows.Forms.ListBox
	Public WithEvents lstPlayListPath As System.Windows.Forms.ListBox
	Public WithEvents Timer1 As System.Windows.Forms.Timer
	Public WithEvents chkMute As System.Windows.Forms.CheckBox
	Public WithEvents Volume As AxMyControls.AxSeekLine
	Public WithEvents Negative As AxMyControls.AxCustomControl
	Public WithEvents _MusicTime_2 As AxMyControls.AxCustomControl
	Public WithEvents Colon As AxMyControls.AxCustomControl
	Public WithEvents _MusicTime_0 As AxMyControls.AxCustomControl
	Public WithEvents _MusicTime_1 As AxMyControls.AxCustomControl
	Public WithEvents _MusicTime_3 As AxMyControls.AxCustomControl
	Public WithEvents BlankSpace As AxMyControls.AxCustomControl
	Public WithEvents Label1 As System.Windows.Forms.Label
	Public WithEvents picClock As System.Windows.Forms.Panel
	Public WithEvents _optMerge_2 As System.Windows.Forms.RadioButton
	Public WithEvents _optMerge_1 As System.Windows.Forms.RadioButton
	Public WithEvents _optMerge_0 As System.Windows.Forms.RadioButton
	Public WithEvents _optClipMark_1 As System.Windows.Forms.RadioButton
	Public WithEvents _optClipMark_0 As System.Windows.Forms.RadioButton
	Public WithEvents Frame1 As System.Windows.Forms.GroupBox
	Public WithEvents Minimized As AxMyControls.AxCustomControl
	Public WithEvents CloseApp As AxMyControls.AxCustomControl
	Public WithEvents Progress As AxMyControls.AxProgressBar
    Public WithEvents fltRemove As AxMyControls.AxFlatButton
    Public WithEvents CustomControl2 As AxMyControls.AxCustomControl
    Public WithEvents CustomControl1 As AxMyControls.AxCustomControl
    Public WithEvents Pos As AxMyControls.AxSeekLine
    Public WithEvents OpenFiles As AxMyControls.AxCustomControl
    Public WithEvents Stop_Renamed As AxMyControls.AxCustomControl
    Public WithEvents Pause As AxMyControls.AxCustomControl
    Public WithEvents Play As AxMyControls.AxCustomControl
    Public WithEvents Forward As AxMyControls.AxCustomControl
    Public WithEvents Rewind As AxMyControls.AxCustomControl
    Public WithEvents _fltTab_0 As AxMyControls.AxFlatButton
    Public WithEvents _fltTab_1 As AxMyControls.AxFlatButton
    Public WithEvents _fltTab_2 As AxMyControls.AxFlatButton
    Public WithEvents fltCutAndSave As AxMyControls.AxFlatButton
    Public WithEvents _fltBrowse_0 As AxMyControls.AxFlatButton
    Public WithEvents _fltBrowse_1 As AxMyControls.AxFlatButton
    Public WithEvents fltDivide As AxMyControls.AxFlatButton
    Public WithEvents fltMerge As AxMyControls.AxFlatButton
    Public WithEvents _fltTab_3 As AxMyControls.AxFlatButton
    Public WithEvents Shape1 As System.Windows.Forms.Label
    Public WithEvents lblHelp As System.Windows.Forms.Label
    Public WithEvents _Label_0 As System.Windows.Forms.Label
    Public WithEvents _Label_1 As System.Windows.Forms.Label
    Public WithEvents _Label_2 As System.Windows.Forms.Label
    Public WithEvents _Label2_0 As System.Windows.Forms.Label
    Public WithEvents _Label2_1 As System.Windows.Forms.Label
    Public WithEvents _imgHelp_0 As System.Windows.Forms.PictureBox
    Public WithEvents _imgHelp_1 As System.Windows.Forms.PictureBox
    Public WithEvents _lblAbout_0 As System.Windows.Forms.Label
    Public WithEvents _lblAbout_1 As System.Windows.Forms.Label
    Public WithEvents _lblAbout_2 As System.Windows.Forms.Label
    Public WithEvents imgBar As System.Windows.Forms.PictureBox
    Public WithEvents Label As Microsoft.VisualBasic.Compatibility.VB6.LabelArray
    Public WithEvents Label2 As Microsoft.VisualBasic.Compatibility.VB6.LabelArray
    Public WithEvents MusicTime As AxCustomControlArray.AxCustomControlArray
    Public WithEvents fltBrowse As AxFlatButtonArray.AxFlatButtonArray
    Public WithEvents fltTab As AxFlatButtonArray.AxFlatButtonArray
    Public WithEvents imgHelp As Microsoft.VisualBasic.Compatibility.VB6.PictureBoxArray
    Public WithEvents lblAbout As Microsoft.VisualBasic.Compatibility.VB6.LabelArray
    Public WithEvents optClipMark As Microsoft.VisualBasic.Compatibility.VB6.RadioButtonArray
    Public WithEvents optMerge As Microsoft.VisualBasic.Compatibility.VB6.RadioButtonArray
    Public WithEvents txtTime As AxGraphic_TxtBoxArray.AxGraphic_TxtBoxArray
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me._optClipMark_1 = New System.Windows.Forms.RadioButton
        Me._optClipMark_0 = New System.Windows.Forms.RadioButton
        Me.Command1 = New System.Windows.Forms.Button
        Me.Command2 = New System.Windows.Forms.Button
        Me.lstPlayList = New System.Windows.Forms.ListBox
        Me.lstPlayListPath = New System.Windows.Forms.ListBox
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.picClock = New System.Windows.Forms.Panel
        Me.chkMute = New System.Windows.Forms.CheckBox
        Me.Volume = New AxMyControls.AxSeekLine
        Me.Negative = New AxMyControls.AxCustomControl
        Me._MusicTime_2 = New AxMyControls.AxCustomControl
        Me.Colon = New AxMyControls.AxCustomControl
        Me._MusicTime_0 = New AxMyControls.AxCustomControl
        Me._MusicTime_1 = New AxMyControls.AxCustomControl
        Me._MusicTime_3 = New AxMyControls.AxCustomControl
        Me.BlankSpace = New AxMyControls.AxCustomControl
        Me.Label1 = New System.Windows.Forms.Label
        Me._optMerge_2 = New System.Windows.Forms.RadioButton
        Me._optMerge_1 = New System.Windows.Forms.RadioButton
        Me._optMerge_0 = New System.Windows.Forms.RadioButton
        Me.Frame1 = New System.Windows.Forms.GroupBox
        Me.Minimized = New AxMyControls.AxCustomControl
        Me.CloseApp = New AxMyControls.AxCustomControl
        Me.Progress = New AxMyControls.AxProgressBar
        Me.fltRemove = New AxMyControls.AxFlatButton
        Me.CustomControl2 = New AxMyControls.AxCustomControl
        Me.CustomControl1 = New AxMyControls.AxCustomControl
        Me.Pos = New AxMyControls.AxSeekLine
        Me.OpenFiles = New AxMyControls.AxCustomControl
        Me.Stop_Renamed = New AxMyControls.AxCustomControl
        Me.Pause = New AxMyControls.AxCustomControl
        Me.Play = New AxMyControls.AxCustomControl
        Me.Forward = New AxMyControls.AxCustomControl
        Me.Rewind = New AxMyControls.AxCustomControl
        Me._fltTab_0 = New AxMyControls.AxFlatButton
        Me._fltTab_1 = New AxMyControls.AxFlatButton
        Me._fltTab_2 = New AxMyControls.AxFlatButton
        Me.fltCutAndSave = New AxMyControls.AxFlatButton
        Me._fltBrowse_0 = New AxMyControls.AxFlatButton
        Me._fltBrowse_1 = New AxMyControls.AxFlatButton
        Me.fltDivide = New AxMyControls.AxFlatButton
        Me.fltMerge = New AxMyControls.AxFlatButton
        Me._fltTab_3 = New AxMyControls.AxFlatButton
        Me.Shape1 = New System.Windows.Forms.Label
        Me.lblHelp = New System.Windows.Forms.Label
        Me._Label_0 = New System.Windows.Forms.Label
        Me._Label_1 = New System.Windows.Forms.Label
        Me._Label_2 = New System.Windows.Forms.Label
        Me._Label2_0 = New System.Windows.Forms.Label
        Me._Label2_1 = New System.Windows.Forms.Label
        Me._imgHelp_0 = New System.Windows.Forms.PictureBox
        Me._imgHelp_1 = New System.Windows.Forms.PictureBox
        Me._lblAbout_0 = New System.Windows.Forms.Label
        Me._lblAbout_1 = New System.Windows.Forms.Label
        Me._lblAbout_2 = New System.Windows.Forms.Label
        Me.imgBar = New System.Windows.Forms.PictureBox
        Me.Label = New Microsoft.VisualBasic.Compatibility.VB6.LabelArray(Me.components)
        Me.Label2 = New Microsoft.VisualBasic.Compatibility.VB6.LabelArray(Me.components)
        Me.MusicTime = New AxCustomControlArray.AxCustomControlArray(Me.components)
        Me.fltBrowse = New AxFlatButtonArray.AxFlatButtonArray(Me.components)
        Me.fltTab = New AxFlatButtonArray.AxFlatButtonArray(Me.components)
        Me.imgHelp = New Microsoft.VisualBasic.Compatibility.VB6.PictureBoxArray(Me.components)
        Me.lblAbout = New Microsoft.VisualBasic.Compatibility.VB6.LabelArray(Me.components)
        Me.optClipMark = New Microsoft.VisualBasic.Compatibility.VB6.RadioButtonArray(Me.components)
        Me.optMerge = New Microsoft.VisualBasic.Compatibility.VB6.RadioButtonArray(Me.components)
        Me.txtTime = New AxGraphic_TxtBoxArray.AxGraphic_TxtBoxArray(Me.components)
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog
        Me.txtDir1 = New System.Windows.Forms.TextBox
        Me.txtSource1 = New System.Windows.Forms.TextBox
        Me._txtTime_0 = New System.Windows.Forms.TextBox
        Me._txtTime_1 = New System.Windows.Forms.TextBox
        Me.txtNumDivide = New System.Windows.Forms.TextBox
        Me.picClock.SuspendLayout()
        CType(Me.Volume, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Negative, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._MusicTime_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Colon, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._MusicTime_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._MusicTime_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._MusicTime_3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BlankSpace, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Frame1.SuspendLayout()
        CType(Me.Minimized, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CloseApp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Progress, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.fltRemove, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CustomControl2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CustomControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pos, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.OpenFiles, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Stop_Renamed, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Pause, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Play, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Forward, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Rewind, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._fltTab_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._fltTab_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._fltTab_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.fltCutAndSave, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._fltBrowse_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._fltBrowse_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.fltDivide, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.fltMerge, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._fltTab_3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imgHelp_0, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me._imgHelp_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgBar, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Label2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MusicTime, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.fltBrowse, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.fltTab, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgHelp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.lblAbout, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.optClipMark, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.optMerge, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTime, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        '_optClipMark_1
        '
        Me._optClipMark_1.Appearance = System.Windows.Forms.Appearance.Button
        Me._optClipMark_1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._optClipMark_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._optClipMark_1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._optClipMark_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me._optClipMark_1.Image = CType(resources.GetObject("_optClipMark_1.Image"), System.Drawing.Image)
        Me.optClipMark.SetIndex(Me._optClipMark_1, CType(1, Short))
        Me._optClipMark_1.Location = New System.Drawing.Point(32, 8)
        Me._optClipMark_1.Name = "_optClipMark_1"
        Me._optClipMark_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._optClipMark_1.Size = New System.Drawing.Size(33, 25)
        Me._optClipMark_1.TabIndex = 4
        Me._optClipMark_1.TabStop = True
        Me._optClipMark_1.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ToolTip1.SetToolTip(Me._optClipMark_1, "Step 2: Clip Mark Out   ")
        Me._optClipMark_1.UseVisualStyleBackColor = False
        Me._optClipMark_1.Visible = False
        '
        '_optClipMark_0
        '
        Me._optClipMark_0.Appearance = System.Windows.Forms.Appearance.Button
        Me._optClipMark_0.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me._optClipMark_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._optClipMark_0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._optClipMark_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me._optClipMark_0.Image = CType(resources.GetObject("_optClipMark_0.Image"), System.Drawing.Image)
        Me.optClipMark.SetIndex(Me._optClipMark_0, CType(0, Short))
        Me._optClipMark_0.Location = New System.Drawing.Point(0, 8)
        Me._optClipMark_0.Name = "_optClipMark_0"
        Me._optClipMark_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._optClipMark_0.Size = New System.Drawing.Size(33, 25)
        Me._optClipMark_0.TabIndex = 3
        Me._optClipMark_0.TabStop = True
        Me._optClipMark_0.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.ToolTip1.SetToolTip(Me._optClipMark_0, "Step 1: Clip Mark In")
        Me._optClipMark_0.UseVisualStyleBackColor = False
        Me._optClipMark_0.Visible = False
        '
        'Command1
        '
        Me.Command1.BackColor = System.Drawing.SystemColors.Control
        Me.Command1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Command1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Command1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Command1.Location = New System.Drawing.Point(288, 288)
        Me.Command1.Name = "Command1"
        Me.Command1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Command1.Size = New System.Drawing.Size(169, 29)
        Me.Command1.TabIndex = 55
        Me.Command1.Text = "Internet Link"
        Me.Command1.UseVisualStyleBackColor = False
        '
        'Command2
        '
        Me.Command2.BackColor = System.Drawing.SystemColors.Control
        Me.Command2.Cursor = System.Windows.Forms.Cursors.Default
        Me.Command2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Command2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Command2.Location = New System.Drawing.Point(288, 328)
        Me.Command2.Name = "Command2"
        Me.Command2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Command2.Size = New System.Drawing.Size(169, 25)
        Me.Command2.TabIndex = 56
        Me.Command2.Text = "Video Player"
        Me.Command2.UseVisualStyleBackColor = False
        '
        'lstPlayList
        '
        Me.lstPlayList.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.lstPlayList.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lstPlayList.Cursor = System.Windows.Forms.Cursors.Default
        Me.lstPlayList.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstPlayList.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lstPlayList.ItemHeight = 14
        Me.lstPlayList.Location = New System.Drawing.Point(280, 24)
        Me.lstPlayList.Name = "lstPlayList"
        Me.lstPlayList.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lstPlayList.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended
        Me.lstPlayList.Size = New System.Drawing.Size(177, 226)
        Me.lstPlayList.TabIndex = 23
        '
        'lstPlayListPath
        '
        Me.lstPlayListPath.BackColor = System.Drawing.SystemColors.Window
        Me.lstPlayListPath.Cursor = System.Windows.Forms.Cursors.Default
        Me.lstPlayListPath.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstPlayListPath.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lstPlayListPath.ItemHeight = 14
        Me.lstPlayListPath.Location = New System.Drawing.Point(328, 160)
        Me.lstPlayListPath.Name = "lstPlayListPath"
        Me.lstPlayListPath.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lstPlayListPath.Size = New System.Drawing.Size(49, 46)
        Me.lstPlayListPath.TabIndex = 22
        Me.lstPlayListPath.Visible = False
        '
        'Timer1
        '
        Me.Timer1.Interval = 1000
        '
        'picClock
        '
        Me.picClock.BackColor = System.Drawing.Color.Black
        Me.picClock.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.picClock.Controls.Add(Me.chkMute)
        Me.picClock.Controls.Add(Me.Volume)
        Me.picClock.Controls.Add(Me.Negative)
        Me.picClock.Controls.Add(Me._MusicTime_2)
        Me.picClock.Controls.Add(Me.Colon)
        Me.picClock.Controls.Add(Me._MusicTime_0)
        Me.picClock.Controls.Add(Me._MusicTime_1)
        Me.picClock.Controls.Add(Me._MusicTime_3)
        Me.picClock.Controls.Add(Me.BlankSpace)
        Me.picClock.Controls.Add(Me.Label1)
        Me.picClock.Cursor = System.Windows.Forms.Cursors.Default
        Me.picClock.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.picClock.ForeColor = System.Drawing.SystemColors.ControlText
        Me.picClock.Location = New System.Drawing.Point(32, 26)
        Me.picClock.Name = "picClock"
        Me.picClock.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.picClock.Size = New System.Drawing.Size(220, 27)
        Me.picClock.TabIndex = 11
        Me.picClock.TabStop = True
        '
        'chkMute
        '
        Me.chkMute.BackColor = System.Drawing.Color.Black
        Me.chkMute.Cursor = System.Windows.Forms.Cursors.Default
        Me.chkMute.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.chkMute.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkMute.ForeColor = System.Drawing.Color.White
        Me.chkMute.Location = New System.Drawing.Point(160, 10)
        Me.chkMute.Name = "chkMute"
        Me.chkMute.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.chkMute.Size = New System.Drawing.Size(44, 13)
        Me.chkMute.TabIndex = 12
        Me.chkMute.Text = "Mute"
        Me.chkMute.UseVisualStyleBackColor = False
        '
        'Volume
        '
        Me.Volume.Enabled = True
        Me.Volume.Location = New System.Drawing.Point(104, 0)
        Me.Volume.Name = "Volume"
        Me.Volume.OcxState = CType(resources.GetObject("Volume.OcxState"), System.Windows.Forms.AxHost.State)
        Me.Volume.Size = New System.Drawing.Size(105, 20)
        Me.Volume.TabIndex = 13
        '
        'Negative
        '
        Me.Negative.Enabled = True
        Me.Negative.Location = New System.Drawing.Point(1, 0)
        Me.Negative.Name = "Negative"
        Me.Negative.OcxState = CType(resources.GetObject("Negative.OcxState"), System.Windows.Forms.AxHost.State)
        Me.Negative.Size = New System.Drawing.Size(14, 20)
        Me.Negative.TabIndex = 14
        Me.Negative.Visible = False
        '
        '_MusicTime_2
        '
        Me._MusicTime_2.Enabled = True
        Me.MusicTime.SetIndex(Me._MusicTime_2, CType(2, Short))
        Me._MusicTime_2.Location = New System.Drawing.Point(63, 0)
        Me._MusicTime_2.Name = "_MusicTime_2"
        Me._MusicTime_2.OcxState = CType(resources.GetObject("_MusicTime_2.OcxState"), System.Windows.Forms.AxHost.State)
        Me._MusicTime_2.Size = New System.Drawing.Size(14, 20)
        Me._MusicTime_2.TabIndex = 15
        '
        'Colon
        '
        Me.Colon.Enabled = True
        Me.Colon.Location = New System.Drawing.Point(48, 0)
        Me.Colon.Name = "Colon"
        Me.Colon.OcxState = CType(resources.GetObject("Colon.OcxState"), System.Windows.Forms.AxHost.State)
        Me.Colon.Size = New System.Drawing.Size(14, 20)
        Me.Colon.TabIndex = 16
        '
        '_MusicTime_0
        '
        Me._MusicTime_0.Enabled = True
        Me.MusicTime.SetIndex(Me._MusicTime_0, CType(0, Short))
        Me._MusicTime_0.Location = New System.Drawing.Point(16, 0)
        Me._MusicTime_0.Name = "_MusicTime_0"
        Me._MusicTime_0.OcxState = CType(resources.GetObject("_MusicTime_0.OcxState"), System.Windows.Forms.AxHost.State)
        Me._MusicTime_0.Size = New System.Drawing.Size(14, 20)
        Me._MusicTime_0.TabIndex = 17
        '
        '_MusicTime_1
        '
        Me._MusicTime_1.Enabled = True
        Me.MusicTime.SetIndex(Me._MusicTime_1, CType(1, Short))
        Me._MusicTime_1.Location = New System.Drawing.Point(32, 0)
        Me._MusicTime_1.Name = "_MusicTime_1"
        Me._MusicTime_1.OcxState = CType(resources.GetObject("_MusicTime_1.OcxState"), System.Windows.Forms.AxHost.State)
        Me._MusicTime_1.Size = New System.Drawing.Size(14, 20)
        Me._MusicTime_1.TabIndex = 18
        '
        '_MusicTime_3
        '
        Me._MusicTime_3.Enabled = True
        Me.MusicTime.SetIndex(Me._MusicTime_3, CType(3, Short))
        Me._MusicTime_3.Location = New System.Drawing.Point(79, 0)
        Me._MusicTime_3.Name = "_MusicTime_3"
        Me._MusicTime_3.OcxState = CType(resources.GetObject("_MusicTime_3.OcxState"), System.Windows.Forms.AxHost.State)
        Me._MusicTime_3.Size = New System.Drawing.Size(14, 20)
        Me._MusicTime_3.TabIndex = 19
        '
        'BlankSpace
        '
        Me.BlankSpace.Enabled = True
        Me.BlankSpace.Location = New System.Drawing.Point(1, 0)
        Me.BlankSpace.Name = "BlankSpace"
        Me.BlankSpace.OcxState = CType(resources.GetObject("BlankSpace.OcxState"), System.Windows.Forms.AxHost.State)
        Me.BlankSpace.Size = New System.Drawing.Size(14, 20)
        Me.BlankSpace.TabIndex = 20
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(120, 10)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(43, 14)
        Me.Label1.TabIndex = 21
        Me.Label1.Text = "Volume"
        '
        '_optMerge_2
        '
        Me._optMerge_2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me._optMerge_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._optMerge_2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._optMerge_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.optMerge.SetIndex(Me._optMerge_2, CType(2, Short))
        Me._optMerge_2.Location = New System.Drawing.Point(16, 256)
        Me._optMerge_2.Name = "_optMerge_2"
        Me._optMerge_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._optMerge_2.Size = New System.Drawing.Size(113, 17)
        Me._optMerge_2.TabIndex = 7
        Me._optMerge_2.TabStop = True
        Me._optMerge_2.Text = "Insert at middle"
        Me._optMerge_2.UseVisualStyleBackColor = False
        Me._optMerge_2.Visible = False
        '
        '_optMerge_1
        '
        Me._optMerge_1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me._optMerge_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._optMerge_1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._optMerge_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.optMerge.SetIndex(Me._optMerge_1, CType(1, Short))
        Me._optMerge_1.Location = New System.Drawing.Point(16, 288)
        Me._optMerge_1.Name = "_optMerge_1"
        Me._optMerge_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._optMerge_1.Size = New System.Drawing.Size(105, 17)
        Me._optMerge_1.TabIndex = 6
        Me._optMerge_1.TabStop = True
        Me._optMerge_1.Text = "Insert at end"
        Me._optMerge_1.UseVisualStyleBackColor = False
        Me._optMerge_1.Visible = False
        '
        '_optMerge_0
        '
        Me._optMerge_0.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me._optMerge_0.Checked = True
        Me._optMerge_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._optMerge_0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._optMerge_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me.optMerge.SetIndex(Me._optMerge_0, CType(0, Short))
        Me._optMerge_0.Location = New System.Drawing.Point(16, 272)
        Me._optMerge_0.Name = "_optMerge_0"
        Me._optMerge_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._optMerge_0.Size = New System.Drawing.Size(105, 17)
        Me._optMerge_0.TabIndex = 5
        Me._optMerge_0.TabStop = True
        Me._optMerge_0.Text = "Insert at start"
        Me._optMerge_0.UseVisualStyleBackColor = False
        Me._optMerge_0.Visible = False
        '
        'Frame1
        '
        Me.Frame1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Frame1.Controls.Add(Me._optClipMark_1)
        Me.Frame1.Controls.Add(Me._optClipMark_0)
        Me.Frame1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame1.Location = New System.Drawing.Point(16, 170)
        Me.Frame1.Name = "Frame1"
        Me.Frame1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Frame1.Size = New System.Drawing.Size(67, 35)
        Me.Frame1.TabIndex = 2
        Me.Frame1.TabStop = False
        '
        'Minimized
        '
        Me.Minimized.Enabled = True
        Me.Minimized.Location = New System.Drawing.Point(424, 3)
        Me.Minimized.Name = "Minimized"
        Me.Minimized.OcxState = CType(resources.GetObject("Minimized.OcxState"), System.Windows.Forms.AxHost.State)
        Me.Minimized.Size = New System.Drawing.Size(15, 15)
        Me.Minimized.TabIndex = 1
        '
        'CloseApp
        '
        Me.CloseApp.Enabled = True
        Me.CloseApp.Location = New System.Drawing.Point(448, 3)
        Me.CloseApp.Name = "CloseApp"
        Me.CloseApp.OcxState = CType(resources.GetObject("CloseApp.OcxState"), System.Windows.Forms.AxHost.State)
        Me.CloseApp.Size = New System.Drawing.Size(15, 15)
        Me.CloseApp.TabIndex = 0
        '
        'Progress
        '
        Me.Progress.Enabled = True
        Me.Progress.Location = New System.Drawing.Point(16, 320)
        Me.Progress.Name = "Progress"
        Me.Progress.OcxState = CType(resources.GetObject("Progress.OcxState"), System.Windows.Forms.AxHost.State)
        Me.Progress.Size = New System.Drawing.Size(249, 17)
        Me.Progress.TabIndex = 8
        Me.Progress.Visible = False
        '
        'fltRemove
        '
        Me.fltRemove.Enabled = True
        Me.fltRemove.Location = New System.Drawing.Point(288, 256)
        Me.fltRemove.Name = "fltRemove"
        Me.fltRemove.OcxState = CType(resources.GetObject("fltRemove.OcxState"), System.Windows.Forms.AxHost.State)
        Me.fltRemove.Size = New System.Drawing.Size(169, 24)
        Me.fltRemove.TabIndex = 10
        '
        'CustomControl2
        '
        Me.CustomControl2.Enabled = True
        Me.CustomControl2.Location = New System.Drawing.Point(7, 56)
        Me.CustomControl2.Name = "CustomControl2"
        Me.CustomControl2.OcxState = CType(resources.GetObject("CustomControl2.OcxState"), System.Windows.Forms.AxHost.State)
        Me.CustomControl2.Size = New System.Drawing.Size(25, 54)
        Me.CustomControl2.TabIndex = 24
        '
        'CustomControl1
        '
        Me.CustomControl1.Enabled = True
        Me.CustomControl1.Location = New System.Drawing.Point(249, 56)
        Me.CustomControl1.Name = "CustomControl1"
        Me.CustomControl1.OcxState = CType(resources.GetObject("CustomControl1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.CustomControl1.Size = New System.Drawing.Size(25, 54)
        Me.CustomControl1.TabIndex = 25
        '
        'Pos
        '
        Me.Pos.Enabled = True
        Me.Pos.Location = New System.Drawing.Point(32, 72)
        Me.Pos.Name = "Pos"
        Me.Pos.OcxState = CType(resources.GetObject("Pos.OcxState"), System.Windows.Forms.AxHost.State)
        Me.Pos.Size = New System.Drawing.Size(217, 20)
        Me.Pos.TabIndex = 26
        '
        'OpenFiles
        '
        Me.OpenFiles.Enabled = True
        Me.OpenFiles.Location = New System.Drawing.Point(200, 96)
        Me.OpenFiles.Name = "OpenFiles"
        Me.OpenFiles.OcxState = CType(resources.GetObject("OpenFiles.OcxState"), System.Windows.Forms.AxHost.State)
        Me.OpenFiles.Size = New System.Drawing.Size(37, 39)
        Me.OpenFiles.TabIndex = 27
        '
        'Stop_Renamed
        '
        Me.Stop_Renamed.Enabled = True
        Me.Stop_Renamed.Location = New System.Drawing.Point(136, 96)
        Me.Stop_Renamed.Name = "Stop_Renamed"
        Me.Stop_Renamed.OcxState = CType(resources.GetObject("Stop_Renamed.OcxState"), System.Windows.Forms.AxHost.State)
        Me.Stop_Renamed.Size = New System.Drawing.Size(37, 39)
        Me.Stop_Renamed.TabIndex = 28
        '
        'Pause
        '
        Me.Pause.Enabled = True
        Me.Pause.Location = New System.Drawing.Point(104, 96)
        Me.Pause.Name = "Pause"
        Me.Pause.OcxState = CType(resources.GetObject("Pause.OcxState"), System.Windows.Forms.AxHost.State)
        Me.Pause.Size = New System.Drawing.Size(37, 39)
        Me.Pause.TabIndex = 29
        '
        'Play
        '
        Me.Play.Enabled = True
        Me.Play.Location = New System.Drawing.Point(72, 96)
        Me.Play.Name = "Play"
        Me.Play.OcxState = CType(resources.GetObject("Play.OcxState"), System.Windows.Forms.AxHost.State)
        Me.Play.Size = New System.Drawing.Size(37, 39)
        Me.Play.TabIndex = 30
        '
        'Forward
        '
        Me.Forward.Enabled = True
        Me.Forward.Location = New System.Drawing.Point(168, 96)
        Me.Forward.Name = "Forward"
        Me.Forward.OcxState = CType(resources.GetObject("Forward.OcxState"), System.Windows.Forms.AxHost.State)
        Me.Forward.Size = New System.Drawing.Size(37, 39)
        Me.Forward.TabIndex = 31
        '
        'Rewind
        '
        Me.Rewind.Enabled = True
        Me.Rewind.Location = New System.Drawing.Point(40, 96)
        Me.Rewind.Name = "Rewind"
        Me.Rewind.OcxState = CType(resources.GetObject("Rewind.OcxState"), System.Windows.Forms.AxHost.State)
        Me.Rewind.Size = New System.Drawing.Size(37, 39)
        Me.Rewind.TabIndex = 32
        '
        '_fltTab_0
        '
        Me._fltTab_0.Enabled = True
        Me.fltTab.SetIndex(Me._fltTab_0, CType(0, Short))
        Me._fltTab_0.Location = New System.Drawing.Point(8, 144)
        Me._fltTab_0.Name = "_fltTab_0"
        Me._fltTab_0.OcxState = CType(resources.GetObject("_fltTab_0.OcxState"), System.Windows.Forms.AxHost.State)
        Me._fltTab_0.Size = New System.Drawing.Size(65, 25)
        Me._fltTab_0.TabIndex = 33
        '
        '_fltTab_1
        '
        Me._fltTab_1.Enabled = True
        Me.fltTab.SetIndex(Me._fltTab_1, CType(1, Short))
        Me._fltTab_1.Location = New System.Drawing.Point(72, 152)
        Me._fltTab_1.Name = "_fltTab_1"
        Me._fltTab_1.OcxState = CType(resources.GetObject("_fltTab_1.OcxState"), System.Windows.Forms.AxHost.State)
        Me._fltTab_1.Size = New System.Drawing.Size(65, 17)
        Me._fltTab_1.TabIndex = 34
        '
        '_fltTab_2
        '
        Me._fltTab_2.Enabled = True
        Me.fltTab.SetIndex(Me._fltTab_2, CType(2, Short))
        Me._fltTab_2.Location = New System.Drawing.Point(136, 152)
        Me._fltTab_2.Name = "_fltTab_2"
        Me._fltTab_2.OcxState = CType(resources.GetObject("_fltTab_2.OcxState"), System.Windows.Forms.AxHost.State)
        Me._fltTab_2.Size = New System.Drawing.Size(65, 17)
        Me._fltTab_2.TabIndex = 35
        '
        'fltCutAndSave
        '
        Me.fltCutAndSave.Enabled = True
        Me.fltCutAndSave.Location = New System.Drawing.Point(48, 48)
        Me.fltCutAndSave.Name = "fltCutAndSave"
        Me.fltCutAndSave.OcxState = CType(resources.GetObject("fltCutAndSave.OcxState"), System.Windows.Forms.AxHost.State)
        Me.fltCutAndSave.Size = New System.Drawing.Size(105, 25)
        Me.fltCutAndSave.TabIndex = 36
        Me.fltCutAndSave.Visible = False
        '
        '_fltBrowse_0
        '
        Me._fltBrowse_0.Enabled = True
        Me.fltBrowse.SetIndex(Me._fltBrowse_0, CType(0, Short))
        Me._fltBrowse_0.Location = New System.Drawing.Point(184, 184)
        Me._fltBrowse_0.Name = "_fltBrowse_0"
        Me._fltBrowse_0.OcxState = CType(resources.GetObject("_fltBrowse_0.OcxState"), System.Windows.Forms.AxHost.State)
        Me._fltBrowse_0.Size = New System.Drawing.Size(57, 17)
        Me._fltBrowse_0.TabIndex = 37
        Me._fltBrowse_0.Visible = False
        '
        '_fltBrowse_1
        '
        Me._fltBrowse_1.Enabled = True
        Me.fltBrowse.SetIndex(Me._fltBrowse_1, CType(1, Short))
        Me._fltBrowse_1.Location = New System.Drawing.Point(208, 232)
        Me._fltBrowse_1.Name = "_fltBrowse_1"
        Me._fltBrowse_1.OcxState = CType(resources.GetObject("_fltBrowse_1.OcxState"), System.Windows.Forms.AxHost.State)
        Me._fltBrowse_1.Size = New System.Drawing.Size(57, 17)
        Me._fltBrowse_1.TabIndex = 39
        Me._fltBrowse_1.Visible = False
        '
        'fltDivide
        '
        Me.fltDivide.Enabled = True
        Me.fltDivide.Location = New System.Drawing.Point(88, 64)
        Me.fltDivide.Name = "fltDivide"
        Me.fltDivide.OcxState = CType(resources.GetObject("fltDivide.OcxState"), System.Windows.Forms.AxHost.State)
        Me.fltDivide.Size = New System.Drawing.Size(89, 17)
        Me.fltDivide.TabIndex = 41
        Me.fltDivide.Visible = False
        '
        'fltMerge
        '
        Me.fltMerge.Enabled = True
        Me.fltMerge.Location = New System.Drawing.Point(128, 280)
        Me.fltMerge.Name = "fltMerge"
        Me.fltMerge.OcxState = CType(resources.GetObject("fltMerge.OcxState"), System.Windows.Forms.AxHost.State)
        Me.fltMerge.Size = New System.Drawing.Size(137, 25)
        Me.fltMerge.TabIndex = 44
        Me.fltMerge.Visible = False
        '
        '_fltTab_3
        '
        Me._fltTab_3.Enabled = True
        Me.fltTab.SetIndex(Me._fltTab_3, CType(3, Short))
        Me._fltTab_3.Location = New System.Drawing.Point(200, 152)
        Me._fltTab_3.Name = "_fltTab_3"
        Me._fltTab_3.OcxState = CType(resources.GetObject("_fltTab_3.OcxState"), System.Windows.Forms.AxHost.State)
        Me._fltTab_3.Size = New System.Drawing.Size(75, 17)
        Me._fltTab_3.TabIndex = 45
        Me._fltTab_3.Visible = False
        '
        'Shape1
        '
        Me.Shape1.BackColor = System.Drawing.Color.Transparent
        Me.Shape1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Shape1.Location = New System.Drawing.Point(8, 176)
        Me.Shape1.Name = "Shape1"
        Me.Shape1.Size = New System.Drawing.Size(267, 177)
        Me.Shape1.TabIndex = 57
        '
        'lblHelp
        '
        Me.lblHelp.AutoSize = True
        Me.lblHelp.BackColor = System.Drawing.Color.Transparent
        Me.lblHelp.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblHelp.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHelp.ForeColor = System.Drawing.Color.Black
        Me.lblHelp.Location = New System.Drawing.Point(184, 64)
        Me.lblHelp.Name = "lblHelp"
        Me.lblHelp.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblHelp.Size = New System.Drawing.Size(38, 14)
        Me.lblHelp.TabIndex = 54
        Me.lblHelp.Text = "lblHelp"
        Me.lblHelp.Visible = False
        '
        '_Label_0
        '
        Me._Label_0.AutoSize = True
        Me._Label_0.BackColor = System.Drawing.Color.Transparent
        Me._Label_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label_0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label.SetIndex(Me._Label_0, CType(0, Short))
        Me._Label_0.Location = New System.Drawing.Point(16, 224)
        Me._Label_0.Name = "_Label_0"
        Me._Label_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label_0.Size = New System.Drawing.Size(114, 14)
        Me._Label_0.TabIndex = 53
        Me._Label_0.Text = "Source Mp3 file name "
        Me._Label_0.Visible = False
        '
        '_Label_1
        '
        Me._Label_1.AutoSize = True
        Me._Label_1.BackColor = System.Drawing.Color.Transparent
        Me._Label_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label_1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label.SetIndex(Me._Label_1, CType(1, Short))
        Me._Label_1.Location = New System.Drawing.Point(16, 208)
        Me._Label_1.Name = "_Label_1"
        Me._Label_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label_1.Size = New System.Drawing.Size(114, 14)
        Me._Label_1.TabIndex = 52
        Me._Label_1.Text = "Destination dir to save"
        Me._Label_1.Visible = False
        '
        '_Label_2
        '
        Me._Label_2.AutoSize = True
        Me._Label_2.BackColor = System.Drawing.Color.Transparent
        Me._Label_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label_2.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label.SetIndex(Me._Label_2, CType(2, Short))
        Me._Label_2.Location = New System.Drawing.Point(112, 136)
        Me._Label_2.Name = "_Label_2"
        Me._Label_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label_2.Size = New System.Drawing.Size(84, 14)
        Me._Label_2.TabIndex = 51
        Me._Label_2.Text = "Parts to divide : "
        Me._Label_2.Visible = False
        '
        '_Label2_0
        '
        Me._Label2_0.AutoSize = True
        Me._Label2_0.BackColor = System.Drawing.Color.Transparent
        Me._Label2_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label2_0.Enabled = False
        Me._Label2_0.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label2_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.SetIndex(Me._Label2_0, CType(0, Short))
        Me._Label2_0.Location = New System.Drawing.Point(160, 256)
        Me._Label2_0.Name = "_Label2_0"
        Me._Label2_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label2_0.Size = New System.Drawing.Size(23, 14)
        Me._Label2_0.TabIndex = 50
        Me._Label2_0.Text = "Min"
        Me._Label2_0.Visible = False
        '
        '_Label2_1
        '
        Me._Label2_1.AutoSize = True
        Me._Label2_1.BackColor = System.Drawing.Color.Transparent
        Me._Label2_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._Label2_1.Enabled = False
        Me._Label2_1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._Label2_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.SetIndex(Me._Label2_1, CType(1, Short))
        Me._Label2_1.Location = New System.Drawing.Point(216, 256)
        Me._Label2_1.Name = "_Label2_1"
        Me._Label2_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._Label2_1.Size = New System.Drawing.Size(26, 14)
        Me._Label2_1.TabIndex = 49
        Me._Label2_1.Text = "Sec"
        Me._Label2_1.Visible = False
        '
        '_imgHelp_0
        '
        Me._imgHelp_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._imgHelp_0.Image = CType(resources.GetObject("_imgHelp_0.Image"), System.Drawing.Image)
        Me.imgHelp.SetIndex(Me._imgHelp_0, CType(0, Short))
        Me._imgHelp_0.Location = New System.Drawing.Point(200, 216)
        Me._imgHelp_0.Name = "_imgHelp_0"
        Me._imgHelp_0.Size = New System.Drawing.Size(22, 19)
        Me._imgHelp_0.TabIndex = 58
        Me._imgHelp_0.TabStop = False
        Me._imgHelp_0.Visible = False
        '
        '_imgHelp_1
        '
        Me._imgHelp_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._imgHelp_1.Image = CType(resources.GetObject("_imgHelp_1.Image"), System.Drawing.Image)
        Me.imgHelp.SetIndex(Me._imgHelp_1, CType(1, Short))
        Me._imgHelp_1.Location = New System.Drawing.Point(232, 208)
        Me._imgHelp_1.Name = "_imgHelp_1"
        Me._imgHelp_1.Size = New System.Drawing.Size(22, 19)
        Me._imgHelp_1.TabIndex = 59
        Me._imgHelp_1.TabStop = False
        Me._imgHelp_1.Visible = False
        '
        '_lblAbout_0
        '
        Me._lblAbout_0.AutoSize = True
        Me._lblAbout_0.BackColor = System.Drawing.Color.Transparent
        Me._lblAbout_0.Cursor = System.Windows.Forms.Cursors.Default
        Me._lblAbout_0.Font = New System.Drawing.Font("Arial", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._lblAbout_0.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblAbout.SetIndex(Me._lblAbout_0, CType(0, Short))
        Me._lblAbout_0.Location = New System.Drawing.Point(32, 184)
        Me._lblAbout_0.Name = "_lblAbout_0"
        Me._lblAbout_0.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._lblAbout_0.Size = New System.Drawing.Size(203, 42)
        Me._lblAbout_0.TabIndex = 48
        Me._lblAbout_0.Text = "MyControls"
        Me._lblAbout_0.Visible = False
        '
        '_lblAbout_1
        '
        Me._lblAbout_1.AutoSize = True
        Me._lblAbout_1.BackColor = System.Drawing.Color.Transparent
        Me._lblAbout_1.Cursor = System.Windows.Forms.Cursors.Default
        Me._lblAbout_1.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._lblAbout_1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblAbout.SetIndex(Me._lblAbout_1, CType(1, Short))
        Me._lblAbout_1.Location = New System.Drawing.Point(24, 216)
        Me._lblAbout_1.Name = "_lblAbout_1"
        Me._lblAbout_1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._lblAbout_1.Size = New System.Drawing.Size(165, 17)
        Me._lblAbout_1.TabIndex = 47
        Me._lblAbout_1.Text = "Developed  by Sagar & Bijal"
        Me._lblAbout_1.Visible = False
        '
        '_lblAbout_2
        '
        Me._lblAbout_2.AutoSize = True
        Me._lblAbout_2.BackColor = System.Drawing.Color.Transparent
        Me._lblAbout_2.Cursor = System.Windows.Forms.Cursors.Default
        Me._lblAbout_2.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._lblAbout_2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblAbout.SetIndex(Me._lblAbout_2, CType(2, Short))
        Me._lblAbout_2.Location = New System.Drawing.Point(56, 112)
        Me._lblAbout_2.Name = "_lblAbout_2"
        Me._lblAbout_2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me._lblAbout_2.Size = New System.Drawing.Size(0, 17)
        Me._lblAbout_2.TabIndex = 46
        Me._lblAbout_2.Visible = False
        '
        'imgBar
        '
        Me.imgBar.Cursor = System.Windows.Forms.Cursors.Default
        Me.imgBar.Image = CType(resources.GetObject("imgBar.Image"), System.Drawing.Image)
        Me.imgBar.Location = New System.Drawing.Point(0, 0)
        Me.imgBar.Name = "imgBar"
        Me.imgBar.Size = New System.Drawing.Size(473, 22)
        Me.imgBar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.imgBar.TabIndex = 60
        Me.imgBar.TabStop = False
        '
        'MusicTime
        '
        '
        'fltBrowse
        '
        '
        'fltTab
        '
        '
        'optClipMark
        '
        '
        'optMerge
        '
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'txtDir1
        '
        Me.txtDir1.Location = New System.Drawing.Point(89, 183)
        Me.txtDir1.Name = "txtDir1"
        Me.txtDir1.Size = New System.Drawing.Size(100, 20)
        Me.txtDir1.TabIndex = 61
        Me.txtDir1.Visible = False
        '
        'txtSource1
        '
        Me.txtSource1.Location = New System.Drawing.Point(88, 209)
        Me.txtSource1.Name = "txtSource1"
        Me.txtSource1.Size = New System.Drawing.Size(100, 20)
        Me.txtSource1.TabIndex = 61
        Me.txtSource1.Visible = False
        '
        '_txtTime_0
        '
        Me._txtTime_0.Location = New System.Drawing.Point(153, 256)
        Me._txtTime_0.Name = "_txtTime_0"
        Me._txtTime_0.Size = New System.Drawing.Size(33, 20)
        Me._txtTime_0.TabIndex = 61
        Me._txtTime_0.Text = "00"
        Me._txtTime_0.Visible = False
        '
        '_txtTime_1
        '
        Me._txtTime_1.Location = New System.Drawing.Point(209, 256)
        Me._txtTime_1.Name = "_txtTime_1"
        Me._txtTime_1.Size = New System.Drawing.Size(33, 20)
        Me._txtTime_1.TabIndex = 61
        Me._txtTime_1.Text = "00"
        Me._txtTime_1.Visible = False
        '
        'txtNumDivide
        '
        Me.txtNumDivide.Location = New System.Drawing.Point(187, 98)
        Me.txtNumDivide.Name = "txtNumDivide"
        Me.txtNumDivide.Size = New System.Drawing.Size(53, 20)
        Me.txtNumDivide.TabIndex = 62
        Me.txtNumDivide.Visible = False
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(472, 362)
        Me.Controls.Add(Me.txtNumDivide)
        Me.Controls.Add(Me._txtTime_1)
        Me.Controls.Add(Me._txtTime_0)
        Me.Controls.Add(Me.txtSource1)
        Me.Controls.Add(Me.txtDir1)
        Me.Controls.Add(Me.Command1)
        Me.Controls.Add(Me.Command2)
        Me.Controls.Add(Me.lstPlayList)
        Me.Controls.Add(Me.lstPlayListPath)
        Me.Controls.Add(Me.picClock)
        Me.Controls.Add(Me._optMerge_2)
        Me.Controls.Add(Me._optMerge_1)
        Me.Controls.Add(Me._optMerge_0)
        Me.Controls.Add(Me.Frame1)
        Me.Controls.Add(Me.Minimized)
        Me.Controls.Add(Me.CloseApp)
        Me.Controls.Add(Me.Progress)
        Me.Controls.Add(Me.fltRemove)
        Me.Controls.Add(Me.CustomControl2)
        Me.Controls.Add(Me.CustomControl1)
        Me.Controls.Add(Me.Pos)
        Me.Controls.Add(Me.OpenFiles)
        Me.Controls.Add(Me.Stop_Renamed)
        Me.Controls.Add(Me.Pause)
        Me.Controls.Add(Me.Play)
        Me.Controls.Add(Me.Forward)
        Me.Controls.Add(Me.Rewind)
        Me.Controls.Add(Me._fltTab_0)
        Me.Controls.Add(Me._fltTab_1)
        Me.Controls.Add(Me._fltTab_2)
        Me.Controls.Add(Me.fltCutAndSave)
        Me.Controls.Add(Me._fltBrowse_0)
        Me.Controls.Add(Me._fltBrowse_1)
        Me.Controls.Add(Me.fltDivide)
        Me.Controls.Add(Me.fltMerge)
        Me.Controls.Add(Me._fltTab_3)
        Me.Controls.Add(Me.Shape1)
        Me.Controls.Add(Me.lblHelp)
        Me.Controls.Add(Me._Label_0)
        Me.Controls.Add(Me._Label_1)
        Me.Controls.Add(Me._Label_2)
        Me.Controls.Add(Me._Label2_0)
        Me.Controls.Add(Me._Label2_1)
        Me.Controls.Add(Me._imgHelp_0)
        Me.Controls.Add(Me._imgHelp_1)
        Me.Controls.Add(Me._lblAbout_0)
        Me.Controls.Add(Me._lblAbout_1)
        Me.Controls.Add(Me._lblAbout_2)
        Me.Controls.Add(Me.imgBar)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(10, 36)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmMain"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.picClock.ResumeLayout(False)
        Me.picClock.PerformLayout()
        CType(Me.Volume, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Negative, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._MusicTime_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Colon, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._MusicTime_0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._MusicTime_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._MusicTime_3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BlankSpace, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Frame1.ResumeLayout(False)
        CType(Me.Minimized, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CloseApp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Progress, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.fltRemove, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CustomControl2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CustomControl1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pos, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.OpenFiles, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Stop_Renamed, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Pause, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Play, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Forward, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Rewind, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._fltTab_0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._fltTab_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._fltTab_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.fltCutAndSave, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._fltBrowse_0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._fltBrowse_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.fltDivide, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.fltMerge, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._fltTab_3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imgHelp_0, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me._imgHelp_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imgBar, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Label2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MusicTime, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.fltBrowse, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.fltTab, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imgHelp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.lblAbout, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.optClipMark, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.optMerge, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTime, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents txtDir1 As System.Windows.Forms.TextBox
    Friend WithEvents txtSource1 As System.Windows.Forms.TextBox
    Friend WithEvents _txtTime_0 As System.Windows.Forms.TextBox
    Friend WithEvents _txtTime_1 As System.Windows.Forms.TextBox
    Friend WithEvents txtNumDivide As System.Windows.Forms.TextBox
#End Region
End Class