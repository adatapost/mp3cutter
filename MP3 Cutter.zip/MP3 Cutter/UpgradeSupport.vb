Module UpgradeSupport
	Friend cBrowseForFolder_definst As New cBrowseForFolder
	Friend cCommonDLG_definst As New cCommonDLG
	Friend cMCI_definst As New cMCI
	Friend MyControlscBrowseForFolder_definst As New MyControls.cBrowseForFolder
	Friend MyControlscCommonDLG_definst As New MyControls.cCommonDLG
	Friend MyControlsClass1_definst As New MyControls.Class1
	Friend MyControlscMCI_definst As New MyControls.cMCI
End Module